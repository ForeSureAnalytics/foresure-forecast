from __future__ import annotations

import pandas as pd


def add_features(df: pd.DataFrame, cfg) -> pd.DataFrame:
    """Placeholder for feature engineering."""
    return df
